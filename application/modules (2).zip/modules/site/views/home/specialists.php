 <div class="Counter-wrap" id="counters">
            
            <div id="third" class="back-color-holder">
                <div class="container">
                <div class="row">
                
                
                <div class="banner-bottom-text2 no-pad col-xs-12 wow fadeInDown" data-wow-delay="0.5s" data-wow-offset="100">
                
                <div class="subtitle">About iMedica</div>
                
                </div>
                
                
                    <!--Counter Box-->
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="counter-box">
                            
                            <div class="counter-style" id="myTargetElement"></div>
                            <div class="counter-lable">Doctors</div>
                            
                        </div>
                    </div>
                    
                    <!--Counter Box-->
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="counter-box">
                            
                            <div class="counter-style" id="myTargetElement2"></div>
                            <div class="counter-lable">Clinic Rooms</div>
                            
                        </div>
                    </div>
                    
                    <!--Counter Box-->
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="counter-box">
                            
                            <div class="counter-style" id="myTargetElement3"></div>
                            <div class="counter-lable">Awards</div>
                            
                        </div>
                    </div>
                    
                    <!--Counter Box-->
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="counter-box">
                            
                            <div class="counter-style" id="myTargetElement4"></div>
                            <div class="counter-lable">Happy Patients</div>
                            
                        </div>
                    </div>
                    
                    
                </div>
                </div>
                </div>
            
            </div>
            