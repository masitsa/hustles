<div class="bread-crumb-wrap ibc-wrap-3">
	<div class="container">
<!--Title / Beadcrumb-->
     	<div class="inner-page-title-wrap col-xs-12 col-md-12 col-sm-12">
        	<div class="bread-heading"><h1>Blog</h1></div>
            <div class="bread-crumb pull-right">
            <ul>
            <li><a href="<?php echo base_url();?>home">Home</a></li>
            <li><a href="<?php echo base_url();?>blog">Absolute Wellness Blog</a></li>
            </ul>
            </div>
        </div>
     </div>
 </div> 