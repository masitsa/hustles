  <div class="container">
            
              <div class="row">
              <!--About-us top-content-->

    
       
            <div class="col-md-12 col-xs-12 col-sm-12 pull-left subtitle subtitle-style ibg-transparent">Showcase Your Content</div>
              <div class="test doctors-3col-tabs">
              <ul class="nav nav-tabs tab-acc" id="myTab">
                        <li class="active"><a href="gallery-3-columns-right-sidebar.html#all-doc" data-toggle="tab">All Doctors</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#primary-health" data-toggle="tab">Health Care</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#pediatric-clinic" data-toggle="tab">Pediatric Clinic</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#dental" data-toggle="tab">Dental Clinic</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#gas" data-toggle="tab">Gastroenterologist</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#rehab" data-toggle="tab">Outpatient Rehab</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#surgery" data-toggle="tab">Outpatient Surgery</a></li>
                      </ul>
                      </div>

              
               <div class="col-xs-12 col-sm-12 col-md-8 doctors-3col-tabs no-pad">
           
                
                  <div class="content-tabs tabs col-xs-12 col-sm-12">
              
                <!-- Nav tabs -->
                      <!--<ul class="nav nav-tabs tab-acc" id="myTab">
                        <li class="active"><a href="#all-doc" data-toggle="tab">All Doctors</a></li>
                        <li><a href="#primary-health" data-toggle="tab">Health Care</a></li>
                        <li><a href="#pediatric-clinic" data-toggle="tab">Pediatric Clinic</a></li>
                        <li><a href="#dental" data-toggle="tab">Dental Clinic</a></li>
                        <li><a href="#gas" data-toggle="tab">Gastroenterologist</a></li>
                        <li><a href="#rehab" data-toggle="tab">Outpatient Rehab</a></li>
                        <li><a href="#surgery" data-toggle="tab">Outpatient Surgery</a></li>
                      </ul>
                      -->
                      <!-- Tab panes -->
                      <div class="tab-content">
                      
                        <div class="tab-pane fade fade-slow in active" id="all-doc">
                        
                        <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                                                     <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInDown animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>

                        
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="primary-health">
                        
                            <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Health Care</span>
                                
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Health Care</span>
                                
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Health Care</span>
                                
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Health Care</span>
                                
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Health Care</span>
                                
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Health Care</span>
                            
                          </div>
                         </div>
                        
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="pediatric-clinic">
                        
                            <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                                  
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                                  
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                                  
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                                  
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-3.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Pediatric Clinic</span>
                                  
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Pediatric Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Pediatric Clinic</span>
                            
                          </div>
                         </div>
                       
                       
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="dental">
                        
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Dental Clinic</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Dental Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Dental Clinic</span>
                            
                          </div>
                         </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Dental Clinic</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Dental Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Dental Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Dental Clinic</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Dental Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Dental Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Dental Clinic</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Dental Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Dental Clinic</span>
                            
                          </div>
                         </div>
                       
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Dental Clinic</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Dental Clinic</span>
                          
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Dental Clinic</span>
                            
                          </div>
                         </div>
                       
                       
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="gas">
                        
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Gastroenterologist</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Gastroenterologist</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Gastroenterologist</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Gastroenterologist</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                         
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-2.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Gastroenterologist</span>
                            
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Gastroenterologist</span>
                                 
                              </div>
                             </div>
                         
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="rehab">
                        
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                             
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Rehab</span>
                            
                          </div>
                         </div>
                         <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                             
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Rehab</span>
                            
                          </div>
                         </div>
                         <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                             
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Rehab</span>
                            
                          </div>
                         </div>
                         <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                             
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Rehab</span>
                            
                          </div>
                         </div>
                         <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                             
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Rehab</span>
                            
                          </div>
                         </div>
                         <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-img-2.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Jack Wong, Prof</div><span class="doc-title">Outpatient Rehab</span>
                                 
                              </div>
                             </div>
                       
                        </div>
                        
                        <div class="tab-pane fade fade-slow" id="surgery">
                        
                        <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Outpatient Surgery</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Outpatient Surgery</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Surgery</span>
                          
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Outpatient Surgery</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Outpatient Surgery</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Surgery</span>
                          
                          </div>
                         </div>
                       
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Outpatient Surgery</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Outpatient Surgery</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Surgery</span>
                          
                          </div>
                         </div>
                       
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Outpatient Surgery</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Outpatient Surgery</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Surgery</span>
                          
                          </div>
                         </div>
                          <!--Doc intro-->
                            <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                            
                              <div class="zoom-wrap">
                              <div class="zoom-icon"></div>
                              <img alt="" class="img-responsive" src="images/mydoc-dummy-1.jpg" />
                              </div>
                              <div class="doc-name">
                                  <div class="doc-name-class">Ashley Morgan, Prof</div><span class="doc-title">Outpatient Surgery</span>
                                 
                              </div>
                             </div>
                             
                             <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-img-1.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Amanda Lauren, Prof</div><span class="doc-title">Outpatient Surgery</span>
                            
                          </div>
                         </div>
                         
                         <!--Doc intro-->
                        <div class="doctor-box col-md-4 col-sm-6 col-xs-12">
                        
                            <div class="zoom-wrap">
                          <div class="zoom-icon"></div>
                            <img alt="" class="img-responsive" src="images/mydoc-dummy-3.jpg" />
                          </div>
                        <div class="doc-name">
                            <div class="doc-name-class">Joe Courtney, Prof</div><span class="doc-title">Outpatient Surgery</span>
                          
                          </div>
                         </div>
                       
                       
                        </div>
                        
                        
                      </div>
           
                 </div> <!--Mid Services End-->

               </div>


                             <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 side-bar-blog">
                    
                    <!--Sidebar-item-->
                    <div class="catagory-list wow fadeInLeft" data-wow-delay="0.5s" data-wow-offset="0">
                    
                        <div class="side-blog-title">Recent Posts</div>
                        <ul>
                        <li><a href="gallery-3-columns-right-sidebar.html#"><i class="fa fa-angle-right about-list-arrows"></i>Doctors (3)</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#"><i class="fa fa-angle-right about-list-arrows"></i>Disease Outbreak (7)</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#"><i class="fa fa-angle-right about-list-arrows"></i>Types of Treatment (4)</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#"><i class="fa fa-angle-right about-list-arrows"></i>Medication Side Effects (5)</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html#"><i class="fa fa-angle-right about-list-arrows"></i>Health and Fitness (2)</a></li>
                        </ul>
                    
                    </div>
                    
                    <!--Sidebar-item-->
                    <div class="post-tabs wow fadeInLeft" data-wow-delay="0.5s" data-wow-offset="50">
                        
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                          <li class="active"><a href="gallery-3-columns-right-sidebar.html#popular" data-toggle="tab">Popular</a></li>
                          <li><a href="gallery-3-columns-right-sidebar.html#recent" data-toggle="tab">Recent</a></li>
                          <li><a href="gallery-3-columns-right-sidebar.html#comment" data-toggle="tab"><i class="icon-comments post-icon"></i>&nbsp;</a></li>
                          
                        </ul>
                        
                        <!-- Tab panes -->
                        <div class="tab-content">
                            
                           <!--popular posts--> 
                          <div class="fade in tab-pane active" id="popular">
                            
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-1.png" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-3.png" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-3-3.jpg" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            
                          </div><!--popular posts end--> 
                          
                          <!--Recent posts-->
                          <div class="tab-pane fade" id="recent">
                          
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-1.png" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-3-3.jpg" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            
                            <div class="popular-post-box">
                                <img alt="" src="images/blog-dummy-3.png" class="img-responsive pull-left" />
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                          
                          </div><!--Recent posts End-->
                          
                          <!--Comments-->
                          <div class="tab-pane fade" id="comment">
                          
                            <div class="popular-post-box">
                                
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            <div class="popular-post-box">
                                
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                            <div class="popular-post-box">
                                
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                          
                          </div><!--Comments end-->
                          
                        </div><!-- Tab panes end-->
                        
                    </div><!-- side item-end -->
                    
                    <!--Sidebar-item-->
                     <!--Sidebar-item end-->
                    
                    <!--Sidebar-item-->
                    <div class="tags-widget wow fadeInLeft" data-wow-delay="0.5s" data-wow-offset="150">
                        
                        <div class="side-blog-title">Tags</div>
                        
                        <ul>
                        <li><a href="gallery-3-columns-right-sidebar.html">Doctors</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">nunc</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">Disease</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">fermentum</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">loremin</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">haaoti</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">vestibulumes</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">tortor</a></li>
                        <li><a href="gallery-3-columns-right-sidebar.html">fila</a></li>
                        </ul>
                    
                    </div><!--Sidebar-item end-->
                    
                    <!--Sidebar-item-->
                    <div class="form-widget wow fadeInLeft" data-wow-delay="0.5s" data-wow-offset="200">
                    
                        <div class="appointment-form-title"><i class="icon-hospital2 appointment-form-icon"></i>Book An Appointment</div>
                        <form class="appt-form">
                        <select class="appt-form-select">
                        <option>Select Department</option>
                        <option>Select Department</option>
                        <option>Select Department</option>
                        <option>Select Department</option>
                        </select>
                        <input type="text" class="appt-form-txt" placeholder="First Name(required)" />
                        <input type="text" class="appt-form-txt" placeholder="Last Name" />
                        <input type="text" class="appt-form-txt" placeholder="Phone(required)" />
                        <input type="email" class="appt-form-txt" placeholder="Email(required)" />
                        <input type="date" class="appt-form-txt" />
                        
                        <section class="color-7" id="btn-click">
                <button class="icon-mail btn2-st2 btn-7 btn-7b iform-button">Submit</button>
                </section>
                        </form>
                    
                    </div><!--Sidebar-item end-->
                    
                    
                    
                    
               </div>
           
           </div>
           </div>
