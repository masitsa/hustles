<div class="col-md-12 col-xs-12 col-sm-12 pull-left full-content wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
            
			<div class="col-md-6 col-sm-12 col-lg-6 col-xs-12 col-md-offset-3 col-lg-offset-3">
			<div class="full-content-title testmonial-client">Testimonials & Clients</div>
            <p>This is what our clients say about the dedication and professionalism at what we offer to the community.</p>
            </div>
       	</div><!--col-md-6 end-->
 
 
 	<!--Bottom Services-->
   
   	<div class="container">
   			<div class="col-xs-12 col-sm-12 col-md-12 pull-left Testiminal-page-wrap no-pad wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
            
            
            	<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="images/test-dummy-1.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">John Doe</div>
                            <div class="testi-author-website">www.themego.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>
             
             <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="images/test-dummy-2.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">Rob Stark</div>
                            <div class="testi-author-website">www.rob.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>
             
             
	       </div>
	    
	 </div><!--container-->