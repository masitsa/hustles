 <div class="container">
    <!--About-us top-content-->

          <div class="row">

     
        	<div class="col-md-12 col-xs-12 col-sm-12 pull-left full-content wow fadeInLeft animated" data-wow-delay="0.3s" data-wow-offset="130">
            <div class="full-content-title about-top-pad">About Us & What We Do</div>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            </div>
            
            
            
             <div class="mid-widgets-serices col-xs-12 col-sm-12 col-md-12 col-lg-12 no-pad pull-left services-page">
         
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-heart panel-icon"></i></div>Heart Disease</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.3s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-eye-open panel-icon"></i></div>Eye Health</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.6s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-female panel-icon"></i></div>Pregnancy</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.9s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-medkit panel-icon"></i></div>Diabetes</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
                      <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-heart panel-icon"></i></div>Heart Disease</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.3s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-eye-open panel-icon"></i></div>Eye Health</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.6s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-female panel-icon"></i></div>Pregnancy</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
            
            <!--service box-->
            <div class="col-sm-5 col-xs-12 col-md-3 col-lg-3 service-box no-pad wow fadeInLeft animated" data-wow-delay="1.9s" data-wow-offset="150">
                <div class="service-title"><div class="service-icon-container rot-y"><i class="icon-medkit panel-icon"></i></div>Diabetes</div>
                <p>Lorem ipsum dolor sit amet, consecte tur adipiscing elit. Ut eu nisl quis augue suscipit dignissim...</p>
                <a href="services-2.html#">read more >></a>
            </div>
                        

         </div> <!--Mid Services End-->

         </div>
         
         </div>