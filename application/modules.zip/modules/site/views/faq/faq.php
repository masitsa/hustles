 <div class="container">
         	
            <div class="row">
            
            <!--About-us top-content-->



				<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 faq-tabs-wrap wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
                    
              <!-- tabs left -->
              <div class="tabbable tabs-left">
                <ul class="nav nav-tabs col-md-4 col-sm-4 col-xs-5">
                  <li class="active"><a href="faq.html#a" data-toggle="tab"><span class="faq-ques">Dolor sit amet elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#b" data-toggle="tab"><span class="faq-ques">Cardiac amet elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#c" data-toggle="tab"><span class="faq-ques">Surgery consectetur  elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#d" data-toggle="tab"><span class="faq-ques">Outpat dolor sit am elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#e" data-toggle="tab"><span class="faq-ques">Clinic si adipiscing elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#f" data-toggle="tab"><span class="faq-ques">dolor sit ametiscing elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#g" data-toggle="tab"><span class="faq-ques">Outpat dolor sit am elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#h" data-toggle="tab"><span class="faq-ques">Clinic dolor si elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#i" data-toggle="tab"><span class="faq-ques">Outpat dolor sit am elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#j" data-toggle="tab"><span class="faq-ques">Surgery adipiscing elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#k" data-toggle="tab"><span class="faq-ques">Outpat dolor sit am elit?</span><i class="right-arr"></i></a></li>
                  <li><a href="faq.html#l" data-toggle="tab"><span class="faq-ques">Surgery adipiscing elit?</span><i class="right-arr"></i></a></li>
                  
                </ul>
                
                <div class="tab-content col-md-8 col-sm-8 col-xs-7 pull-right">
                
                 <div class="tab-pane active" id="a">
                    <div class="dept-title-tabs">Dolor sit amet adipiscing elit?</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="b">
                 <div class="dept-title-tabs">Cardiac amet adipiscing elit?</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                    </div>
                    
                 <div class="tab-pane" id="c">
                 <div class="dept-title-tabs">Outpat dolor sit am elit?</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="d">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="e">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="f">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                   <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="g">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                   <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="h">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="i">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="j">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                   <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="k">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                   <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    
                 </div>
                 
                 <div class="tab-pane" id="l">
                 <div class="dept-title-tabs">Ophthalmology Clinic</div>
                    
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>
                    <p>Integer iaculis egestas odio, vel dictum turpis placerat id ellentesque semper nisl eget odio eleifend, nec blandit libero porta aliquam vel vehicula dui nam sit amet ultricies sapien.</p>
                    <p>Nulla euismod vitae justo a ullamcorper. In rhoncus nisi massa, sit amet tristique augue viverra vitae. Ut vitae lectus quam. Proin aliquet rhoncus magna vel scelerisque. Nulla facilisi. Aliquam ut scelerisque nulla.</p>

                    
                 </div>
                 
                </div>
                
                </div>
        	
            </div>
         
         </div>
         </div>
