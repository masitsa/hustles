<div class="container">
         	
   
            
            <!--About-us top-content-->

        	<div class="col-md-12 col-xs-12 col-sm-12 pull-left subtitle no-pad ibg-transparent">What Our Patients Say</div>
            
            
            <div class="col-xs-12 col-sm-12 col-md-12 pull-left Testiminal-page-wrap no-pad wow fadeInUp animated" data-wow-delay="0.5s" data-wow-offset="200">
            
            
            	<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="<?php echo base_url().'assets/'?>images/absolute.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">John Doe</div>
                            <div class="testi-author-website">www.themego.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>
             
             <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="<?php echo base_url().'assets/'?>images/absolute.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">Rob Stark</div>
                            <div class="testi-author-website">www.rob.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>
             
             <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="<?php echo base_url().'assets/'?>images/absolute.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">Amanda Lauren</div>
                            <div class="testi-author-website">www.amanda.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>
             
             <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 test-box">
                            <div class="testi-author-info">
                        <img alt="" src="<?php echo base_url().'assets/'?>images/absolute.png" class="img-responsive testi-img" />
                            <div class="testi-author-name">Ashley Morgan</div>
                            <div class="testi-author-website">www.ahley.com</div>
                        </div>
                            <p>Etiam tristique sagittis pulvinar. Cras at lectus rhoncus, scelerisque dui ut, bibendum ante. Ut vulputate blandit neque eget lobortis. Nam eleifend sollicitudin nulla quis luctus.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Phas ellus ornare leo risus, at posuere dolor viverra quis. Suspendisse mattis bibendum ultrices. In hac habitasse platea dictumst. Quisque utfaucibus erat curabitur luctus.</p>
             </div>

             


       </div>
            
         
            
 
         
         </div>