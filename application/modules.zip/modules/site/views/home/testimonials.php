 <!--Testimonail Wrap-->
            <div class="testimonial-wrap ihome-testi-wrap">
            
            
                <div class="container">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-left client-logo-flexx wow fadeInUp" data-wow-delay="0.3s" data-wow-offset="100">
                     <i class="fa fa-quote-right testi-quote"></i>
                     <div class="testimonial-content top"></div>
                     
                     <ul id="home-testimonials">
                        <!--Testimonial Item-->    
                        <li>
                        <a class="testi-one testi-1" data-toggle="popover" data-placement="top" data-original-title=' elementum id enim. Curabitur  Quisque velit nisi, pretium ut lacinia in, amet nisl tempus convallis quislacinia in, amet nisl tempus convallis quis ac lectus.' data-content='<span class="testi-client-name">Jhon Snow</span> <br> <span class="testi-client-pos">Creative Officer</span>'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->    
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.' data-content='Rob Stark <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='non nulla sit amet nisl tempus convallis quis ac lectus.Curabitur non nulla sit id enim. Curabitur non nulla siamet nisl tempus convallis quis ac lectus.' data-content='Jhon Snow <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.Curabitur non nulla sit amet nisl tempus Quisque velit nisi, pretium ut lacinia in, elementum convallis quis ac lectus.' data-content='Rob Stark <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='nia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac leQuisque velit nisi, pretium ut lacictus.Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.' data-content='Jhon Snow <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='entum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.Curabitur non nulla sit ameQuisque velit nisi, pretium ut lacinia in, elemt nisl tempus convallis quis ac lectus.' data-content='Rob Stark <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='abitur non nulla sit amet nisl tempus convallis quis ac lectus.Curabitur non nulla Quisque velit nisi, pretium ut lacinia in, elementum id enim. Cursit amet nisl tempus convallis quis ac lectus.' data-content='Jhon Snow <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        <!--Testimonial Item-->
                        <li>
                        <a class="testi-one" data-toggle="popover" data-placement="top" data-original-title='ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.CurQuisque velit nisi, pretium abitur non nulla sit amet nisl tempus convallis quis ac lectus.' data-content='Rob Stark <br> Creative Officer'>
                        <img src="<?php echo base_url().'assets/'?>images/absolute.png" alt="" class="img-responsive client-logo-img" />
                        </a>
                        </li>
                        </ul>  
                     
                     </div>
                        
                </div>
                </div>
            
            </div>
            
        <!--Testimonail Wrap-->