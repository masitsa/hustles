  <div class="cl-wrap icl-wrap">
         <div class="container">
         
         <div class="row">      
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-left client-logo-flex wow fadeInUp" data-wow-delay="0.5s" data-wow-offset="100">
             
                 <ul id="clients-carousel" class="icl-carousel">
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/resolution.jpg" alt="" class="img-responsive client-logo-img"/></a></li>
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/medilink.jpg" alt="" class="img-responsive client-logo-img"/></a></li>
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/logo.png" alt="" class="img-responsive client-logo-img"/></a></li>
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/flexi.jpg" alt="" class="img-responsive client-logo-img"/></a></li>
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/heritage.jpg" alt="" class="img-responsive client-logo-img"/></a></li>
                    <li><a href="index.html#"><img src="<?php echo base_url().'assets/'?>images/clients/fred.jpg" alt="" class="img-responsive client-logo-img"/></a></li>
                </ul>   
             
             </div>
         </div>    
             
         </div>
 </div>