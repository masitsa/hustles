   <div class="purchase-wrap-blue ipurchase-wrap">
        <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 pull-right"> 
                <div class="purchase-strip-blue pull-right col-sm-12 col-md-12 col-xs-12 pull-left notViewed wow fadeInUp" data-wow-delay="0.5s" data-wow-offset="150">
                <div class="purchase-strip-text">BEING  <span class="ipurcahse-strip-text">HEALTHY</span> AND <span class="ipurcahse-strip-text">FIT</span>  IS NOT A FAD OR A TREND INSTEAD, IT IS A <span class="ipurcahse-strip-text">LIFESTYLE</span></div>
                <div class="color-4">
                    <p class="ipurchase-paragraph">
                        <!-- <button class="icon-cart btn btn-4 btn-4a notViewed wow fadeInUp" data-wow-delay="0.5s" data-wow-offset="150">Purchase Theme</button> -->
                    </p>
                </div>
                
                </div>
                
             </div>
          </div>   
          </div>
     </div> 