<?php   if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SMS extends MX_Controller 
{
	
}